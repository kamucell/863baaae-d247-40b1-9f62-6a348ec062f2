namespace GunvorAssessment.Audit
{
	public enum TransactionType
	{
	}
}
