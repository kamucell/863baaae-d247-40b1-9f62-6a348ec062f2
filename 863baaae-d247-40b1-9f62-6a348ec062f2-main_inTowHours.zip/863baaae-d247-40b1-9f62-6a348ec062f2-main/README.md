
Hi,

Sorry for the delay.

>  
>  In two hours, I was only able to implement the account functionality and spent some time working on the audit and transaction features, but I couldn't complete them.
>  
For audit and transaction functionality, I usually prefer an AOP (Aspect-Oriented Programming) approach. I often use libraries like Castle or Autofac (an extension of Castle) for this purpose.


I have added the files containing what I done in two hours.

>  
> The ones listed in the repository are the most recent, and all functionalities is implemented and included.
>  
